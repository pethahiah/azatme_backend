<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMailTemplatesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('mail_templates', function (Blueprint $table) {
            $table->id();
            $table->string('to')->nullable();
            $table->string('email')->nullable();
            $table->string('subject')->nullable();
            $table->string('greetings')->nullable();
            $table->string('url')->nullable();
            $table->string('finalgreetings')->nullable();
            $table->string('salutation')->nullable();
            $table->string('facebookLink')->nullable();
            $table->string('whatsappNumber')->nullable();
            $table->string('campaignImage')->nullable();
            $table->foreignId('customer_id');
            $table->string('message')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('mail_templates');
    }
}
