<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class splittingMethod extends Model
{
    protected $fillable = [
    //
    
    'split'

    ];

   

}
