<?php

namespace Services;


class GroupService{

public function createGroup(Request $request)
{




}

}