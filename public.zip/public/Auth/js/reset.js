// let email3 = document.getElementById("email");
// let resetBtn = document.getElementById("btn");
//
//
// const pageRedirect = (e) => {
//   e.preventDefault();
//   let re = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/;
//
//   if (re.test(email3.value)) {
//     email3.removeAttribute("style", "border:1px solid red !important");
//      window.location.href = "/check_mail";
//   } else {
//     email3.setAttribute("style", "border:1px solid red !important");
//   }
// }
//
//
// resetBtn.addEventListener("click", pageRedirect);
//
