// let password3 = document.getElementById("passwords");
// let confirm_password3 = document.getElementById("confirm_password");
// let resetBtn2 = document.getElementById("btn2");
//
// const changePassword = (e) => {
//     e.preventDefault();
//     let passre = /^[a-zA-Z0-9]{8,}$/;
//     if (passre.test(password3.value)) {
//       password3.removeAttribute("style", "border:1px solid red !important");
//       if (password3.value !== confirm_password3.value) {
//         confirm_password3.setAttribute("style", "border:1px solid red !important");
//       } else {
//         confirm_password3.removeAttribute(
//           "style",
//           "border:1px solid red !important"
//         );
//         window.location.href = "./reset_success.html";
//       }
//     } else {
//       password3.setAttribute("style", "border:1px solid red !important");
//     }
//
//
//
// };
//
//
//   resetBtn2.addEventListener("click", changePassword);
